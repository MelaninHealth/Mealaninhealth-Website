// React shop app placeholder

export default function App(){
  return <div className='p-10'>Melanin Health Shop is working!</div>
}
