import React, { useMemo, useState } from "react";

// --- Simple EUR currency helper ---
const formatEUR = (n) => new Intl.NumberFormat("nl-NL", { style: "currency", currency: "EUR" }).format(n);

// --- Demo product catalog (edit freely) ---
const CATALOG = [
  {
    id: "gel-original",
    name: "Sea Moss Gel – Original",
    description: "Classic, unflavored gold sea moss gel. Keep refrigerated. Best within 3–4 weeks.",
    basePrice: 12.5,
    image: "https://images.unsplash.com/photo-1549395156-3125f94cd0d1?q=80&w=1200&auto=format&fit=crop",
    variants: [
      { key: "250ml", label: "250 ml", price: 12.5 },
      { key: "500ml", label: "500 ml", price: 20 },
      { key: "1l", label: "1 L", price: 36 },
    ],
    tags: ["best-seller", "gel"],
  },
  {
    id: "gel-mango",
    name: "Sea Moss Gel – Mango",
    description: "Tropical mango blend. Lightly sweetened with fruit only.",
    basePrice: 14,
    image: "https://images.unsplash.com/photo-1586201375774-0d58b1d1111c?q=80&w=1200&auto=format&fit=crop",
    variants: [
      { key: "250ml", label: "250 ml", price: 14 },
      { key: "500ml", label: "500 ml", price: 22 },
    ],
    tags: ["flavored", "gel"],
  },
  {
    id: "gel-pineapple",
    name: "Sea Moss Gel – Pineapple Ginger",
    description: "Zesty, refreshing, and great for morning routines.",
    basePrice: 14,
    image: "https://images.unsplash.com/photo-1617093727343-374698b1b08d?q=80&w=1200&auto=format&fit=crop",
    variants: [
      { key: "250ml", label: "250 ml", price: 14 },
      { key: "500ml", label: "500 ml", price: 22 },
    ],
    tags: ["flavored", "gel"],
  },
  {
    id: "bundle-detox",
    name: "Detox Bundle (3 x 500 ml)",
    description: "Pick any 3 flavors (note choices at checkout). Save more in a bundle!",
    basePrice: 58,
    image: "https://images.unsplash.com/photo-1517686469429-8bdb88b9f907?q=80&w=1200&auto=format&fit=crop",
    variants: [
      { key: "default", label: "Standard", price: 58 },
    ],
    tags: ["bundle"],
  },
  {
    id: "cold-pack",
    name: "Insulated Cold Pack (Add-on)",
    description: "Keeps your gel cool during local delivery or pickup.",
    basePrice: 2.5,
    image: "https://images.unsplash.com/photo-1625231162352-a05e4804c0fb?q=80&w=1200&auto=format&fit=crop",
    variants: [
      { key: "one", label: "1 pack", price: 2.5 },
    ],
    tags: ["accessory"],
  },
];

// --- Types ---
/** @typedef {{ id: string; variantKey: string; name: string; price: number; qty: number }} CartLine */

export default function App() {
  const [query, setQuery] = useState("");
  const [cart, setCart] = useState(/** @type {CartLine[]} */([]));
  const [showCart, setShowCart] = useState(false);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return CATALOG;
    return CATALOG.filter(p => [p.name, p.description, ...(p.tags||[])].join(" ").toLowerCase().includes(q));
  }, [query]);

  const cartSubtotal = useMemo(() => cart.reduce((s, l) => s + l.price * l.qty, 0), [cart]);
  const deliveryFee = useMemo(() => (cartSubtotal > 45 ? 0 : cartSubtotal === 0 ? 0 : 4.5), [cartSubtotal]);
  const total = cartSubtotal + deliveryFee;

  function addToCart(product, variantKey) {
    const variant = (product.variants || []).find(v => v.key === variantKey) || product.variants?.[0];
    if (!variant) return;
    const lineId = `${product.id}-${variant.key}`;
    setCart(prev => {
      const existing = prev.find(l => l.id === lineId);
      if (existing) {
        return prev.map(l => (l.id === lineId ? { ...l, qty: l.qty + 1 } : l));
      }
      return [
        ...prev,
        { id: lineId, variantKey: variant.key, name: `${product.name} • ${variant.label}` , price: variant.price, qty: 1 },
      ];
    });
    setShowCart(true);
  }

  function removeFromCart(lineId) {
    setCart(prev => prev.filter(l => l.id !== lineId));
  }

  function updateQty(lineId, delta) {
    setCart(prev => prev.flatMap(l => {
      if (l.id !== lineId) return [l];
      const next = { ...l, qty: l.qty + delta };
      if (next.qty <= 0) return [];
      return [next];
    }));
  }

  function buildOrderText() {
    const lines = cart.map(l => `• ${l.name} x${l.qty} — ${formatEUR(l.price*l.qty)}`);
    const summary = [`Order from Melanin Health`, ...lines, `Subtotal: ${formatEUR(cartSubtotal)}`, `Delivery: ${formatEUR(deliveryFee)}`, `Total: ${formatEUR(total)}`, "\nName:", "Address (Amsterdam or pickup):", "Preferred delivery/pickup date/time:", "Flavor notes for bundles (if any):"].join("\n");
    return encodeURIComponent(summary);
  }

  const whatsappHref = `https://wa.me/31616927046?text=${buildOrderText()}`;
  const emailHref = `mailto:melaninhealth21@gmail.com?subject=${encodeURIComponent("New order – Melanin Health")}&body=${buildOrderText()}`;

  return (
    <div className="min-h-screen bg-white text-neutral-900">
      {/* Top notice bar */}
      <div className="w-full bg-amber-100 text-amber-900 text-sm text-center py-2">Free Amsterdam delivery over €45 • Freshly made weekly • 92 of 102 minerals goodness ✨ • Pick-up in Amsterdam available</div>

      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur bg-white/80 border-b">
        <div className="max-w-6xl mx-auto flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-300 via-yellow-300 to-amber-500" />
            <div className="leading-tight">
              <div className="font-extrabold text-xl tracking-tight">Melanin Health</div>
              <div className="text-xs text-neutral-500 -mt-0.5">Sea Moss • Amsterdam</div>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-6 text-sm">
            <a href="#shop" className="hover:underline">Shop</a>
            <a href="#how" className="hover:underline">How it works</a>
            <a href="#faq" className="hover:underline">FAQ</a>
            <a href="#contact" className="hover:underline">Contact</a>
          </div>
          <div className="flex items-center gap-3">
            <div className="relative">
              <input
                value={query}
                onChange={(e)=>setQuery(e.target.value)}
                placeholder="Search products..."
                className="hidden md:block rounded-xl border px-3 py-2 text-sm focus:outline-none focus:ring w-64"
              />
            </div>
            <button onClick={()=>setShowCart(true)} className="relative rounded-xl border px-3 py-2 text-sm hover:shadow">
              Cart
              <span className="ml-2 inline-flex items-center justify-center min-w-5 h-5 text-xs rounded-full bg-amber-500 text-white px-1">{cart.reduce((s,l)=>s+l.qty,0)}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-10 items-center py-16">
          <div>
            <h1 className="text-4xl md:text-5xl font-extrabold leading-tight">Nourish your body with premium Sea Moss gel</h1>
            <p className="mt-4 text-neutral-600">Handmade in Amsterdam in small batches. Choose original or fruity flavors. Local delivery or pickup.</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a href="#shop" className="rounded-2xl bg-neutral-900 text-white px-5 py-3 text-sm font-semibold">Shop now</a>
              <a href="#how" className="rounded-2xl border px-5 py-3 text-sm">How it works</a>
            </div>
            <ul className="mt-6 text-sm text-neutral-600 grid grid-cols-1 md:grid-cols-3 gap-2">
              <li className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-amber-500"/>Fresh weekly</li>
              <li className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-amber-500"/>No additives</li>
              <li className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-amber-500"/>Made with care</li>
            </ul>
          </div>
          <div className="relative">
            <img src="https://images.unsplash.com/photo-1546069901-eacef0df6022?q=80&w=1600&auto=format&fit=crop" alt="Sea moss gel jars" className="rounded-3xl shadow-lg w-full object-cover aspect-[4/3]"/>
            <div className="absolute -bottom-4 -left-4 bg-white/90 backdrop-blur rounded-2xl shadow p-4 text-sm">
              <div className="font-semibold">Free local delivery</div>
              <div className="text-neutral-600">Over €45 in Amsterdam or pickup option</div>
            </div>
          </div>
        </div>
      </section>

      {/* Shop */}
      <section id="shop" className="max-w-6xl mx-auto px-4 py-14">
        <div className="flex items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold">Shop Sea Moss</h2>
            <p className="text-neutral-600 text-sm">Choose size and add to cart. Delivery in Amsterdam; pickup available.</p>
          </div>
          <input value={query} onChange={(e)=>setQuery(e.target.value)} placeholder="Search products..." className="md:hidden border rounded-xl px-3 py-2 text-sm w-full"/>
        </div>

        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6 mt-6">
          {filtered.map((p) => (
            <article key={p.id} className="border rounded-3xl p-4 hover:shadow transition bg-white flex flex-col">
              <img src={p.image} alt={p.name} className="rounded-2xl aspect-[4/3] object-cover"/>
              <div className="mt-3 flex-1">
                <div className="text-xs uppercase tracking-wide text-amber-600">{p.tags?.join(" • ")}</div>
                <h3 className="font-semibold mt-1 text-lg">{p.name}</h3>
                <p className="text-sm text-neutral-600 mt-1">{p.description}</p>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2">
                {(p.variants||[]).map(v => (
                  <button
                    key={v.key}
                    onClick={()=>addToCart(p, v.key)}
                    className="rounded-xl border px-3 py-2 text-sm hover:bg-amber-50"
                    title={`Add ${p.name} – ${v.label}`}
                  >
                    {v.label}<br/>
                    <span className="font-semibold">{formatEUR(v.price)}</span>
                  </button>
                ))}
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="bg-neutral-50">
        <div className="max-w-6xl mx-auto px-4 py-14">
          <h2 className="text-2xl font-bold">How it works</h2>
          <div className="grid md:grid-cols-3 gap-6 mt-6 text-sm">
            <div className="rounded-3xl bg-white p-6 border">
              <div className="font-semibold">1) Place your order</div>
              <p className="text-neutral-600 mt-2">Choose your jars and flavors. Add an insulated cold pack if needed.</p>
            </div>
            <div className="rounded-3xl bg-white p-6 border">
              <div className="font-semibold">2) Freshly prepared</div>
              <p className="text-neutral-600 mt-2">We make gels in small weekly batches for maximum freshness.</p>
            </div>
            <div className="rounded-3xl bg-white p-6 border">
              <div className="font-semibold">3) Local delivery / pickup</div>
              <p className="text-neutral-600 mt-2">Amsterdam delivery within 1–3 days, or schedule a pickup time.</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="max-w-6xl mx-auto px-4 py-14">
        <h2 className="text-2xl font-bold">FAQ</h2>
        <div className="mt-6 grid md:grid-cols-2 gap-4 text-sm">
          <details className="rounded-2xl border p-4 bg-white">
            <summary className="font-semibold cursor-pointer">How long does sea moss gel last?</summary>
            <p className="mt-2 text-neutral-600">Keep refrigerated. Best within 3–4 weeks. Always use a clean spoon.</p>
          </details>
          <details className="rounded-2xl border p-4 bg-white">
            <summary className="font-semibold cursor-pointer">Do you ship outside Amsterdam?</summary>
            <p className="mt-2 text-neutral-600">We mainly deliver in Amsterdam. Pickup is also available. For nearby areas, contact us to arrange options.</p>
          </details>
          <details className="rounded-2xl border p-4 bg-white">
            <summary className="font-semibold cursor-pointer">Payment methods</summary>
            <p className="mt-2 text-neutral-600">Pay by iDEAL or card using a secure link we send after confirming your order.</p>
          </details>
          <details className="rounded-2xl border p-4 bg-white">
            <summary className="font-semibold cursor-pointer">Allergies & ingredients</summary>
            <p className="mt-2 text-neutral-600">Ingredients: wildcrafted sea moss, spring water, fruit (for flavored gels). No additives.</p>
          </details>
        </div>
      </section>

      {/* Contact / Footer */}
      <section id="contact" className="bg-neutral-900 text-neutral-100">
        <div className="max-w-6xl mx-auto px-4 py-14">
          <h2 className="text-2xl font-bold">Contact & Ordering</h2>
          <p className="text-neutral-300 mt-2 text-sm">Questions or large orders (events, 200+ people)? Get in touch!</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <a href={whatsappHref} target="_blank" rel="noreferrer" className="rounded-2xl bg-white text-neutral-900 px-5 py-3 text-sm font-semibold">Checkout on WhatsApp</a>
            <a href={emailHref} className="rounded-2xl border border-neutral-700 px-5 py-3 text-sm">Checkout via Email</a>
          </div>
          <div className="mt-10 grid md:grid-cols-3 gap-6 text-sm">
            <div>
              <div className="font-semibold">Melanin Health</div>
              <div className="text-neutral-400">Amsterdam, Netherlands</div>
              <div className="text-neutral-400">KVK: •••• •••• (add later)</div>
            </div>
            <div>
              <div className="font-semibold">Legal</div>
              <ul className="mt-2 text-neutral-400 space-y-1">
                <li><a href="#" className="hover:underline">Privacy Policy</a> (placeholder)</li>
                <li><a href="#" className="hover:underline">Terms of Sale</a> (placeholder)</li>
                <li><a href="#" className="hover:underline">Allergen Notice</a> (placeholder)</li>
              </ul>
            </div>
            <div>
              <div className="font-semibold">Follow</div>
              <ul className="mt-2 text-neutral-400 space-y-1">
                <li><a href="https://instagram.com/Melaninhealth21" target="_blank" rel="noreferrer" className="hover:underline">Instagram @Melaninhealth21</a></li>
                <li><a href="#" className="hover:underline">TikTok (coming soon)</a></li>
              </ul>
            </div>
          </div>
          <div className="mt-8 text-xs text-neutral-500">© {new Date().getFullYear()} Melanin Health. All rights reserved.</div>
        </div>
      </section>

      {/* Cart Drawer */}
      {showCart && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/40" onClick={()=>setShowCart(false)} />
          <aside className="absolute right-0 top-0 h-full w-full sm:w-[420px] bg-white shadow-2xl p-5 flex flex-col">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Your Cart</h3>
              <button onClick={()=>setShowCart(false)} className="rounded-xl border px-3 py-1 text-sm">Close</button>
            </div>
            <div className="mt-4 flex-1 overflow-auto space-y-3">
              {cart.length === 0 && <div className="text-sm text-neutral-500">Your cart is empty.</div>}
              {cart.map(line => (
                <div key={line.id} className="border rounded-2xl p-3">
                  <div className="font-medium text-sm">{line.name}</div>
                  <div className="flex items-center justify-between mt-2 text-sm">
                    <div className="flex items-center gap-2">
                      <button onClick={()=>updateQty(line.id, -1)} className="rounded-lg border px-2">-</button>
                      <div className="w-8 text-center">{line.qty}</div>
                      <button onClick={()=>updateQty(line.id, 1)} className="rounded-lg border px-2">+</button>
                    </div>
                    <div className="font-semibold">{formatEUR(line.price * line.qty)}</div>
                  </div>
                  <div className="mt-2 text-right">
                    <button onClick={()=>removeFromCart(line.id)} className="text-xs text-red-600 hover:underline">Remove</button>
                  </div>
                </div>
              ))}
            </div>
            <div className="border-t pt-3 text-sm space-y-1">
              <div className="flex justify-between"><span>Subtotal</span><span>{formatEUR(cartSubtotal)}</span></div>
              <div className="flex justify-between"><span>Delivery</span><span>{deliveryFee === 0 ? "Free" : formatEUR(deliveryFee)}</span></div>
              <div className="flex justify-between font-semibold text-base"><span>Total</span><span>{formatEUR(total)}</span></div>
              <div className="flex gap-2 mt-3">
                <a href={whatsappHref} target="_blank" rel="noreferrer" className="flex-1 text-center rounded-xl bg-neutral-900 text-white px-4 py-2 font-semibold">Checkout on WhatsApp</a>
                <a href={emailHref} className="flex-1 text-center rounded-xl border px-4 py-2">Email Order</a>
              </div>
              <p className="text-xs text-neutral-500 mt-2">Secure payment link (iDEAL/card) will be sent after we confirm your order.</p>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
