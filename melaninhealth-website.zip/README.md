# Melanin Health – Sea Moss Shop (React + Vite + Tailwind)

This is a simple shop for Melanin Health (Amsterdam) with a product catalog, cart, and checkout via WhatsApp or email.

## Local dev
1. Install Node.js 18+
2. Run:
   ```bash
   npm install
   npm run dev
   ```

## Build for production
```bash
npm run build
```

Deploy on Vercel by importing this GitHub repo.
